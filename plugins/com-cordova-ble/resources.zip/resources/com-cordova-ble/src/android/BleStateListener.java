package com.cordova.ble;

/**
 * Project : CouponDemo.
 * Created by Adi on 9/11/2015.
 */
public interface BleStateListener {

    public void onBleStackEvent(int event);
}
